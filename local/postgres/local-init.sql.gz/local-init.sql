--
-- PostgreSQL database dump
--

-- Dumped from database version 13.18 (Debian 13.18-1.pgdg120+1)
-- Dumped by pg_dump version 17.2 (Ubuntu 17.2-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.upvotes DROP CONSTRAINT IF EXISTS "upvotes_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.upvotes DROP CONSTRAINT IF EXISTS "upvotes_feedbackId_fkey";
ALTER TABLE IF EXISTS ONLY public.feedbacks DROP CONSTRAINT IF EXISTS "feedbacks_statusId_fkey";
ALTER TABLE IF EXISTS ONLY public.feedbacks DROP CONSTRAINT IF EXISTS "feedbacks_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.feedbacks DROP CONSTRAINT IF EXISTS "feedbacks_authorId_fkey";
DROP INDEX IF EXISTS public.users_email_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.upvotes DROP CONSTRAINT IF EXISTS upvotes_pkey;
ALTER TABLE IF EXISTS ONLY public.statuses DROP CONSTRAINT IF EXISTS statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.feedbacks DROP CONSTRAINT IF EXISTS feedbacks_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.upvotes;
DROP TABLE IF EXISTS public.statuses;
DROP TABLE IF EXISTS public.feedbacks;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public._prisma_migrations;
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dev
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dev;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public._prisma_migrations (
                                         id character varying(36) NOT NULL,
                                         checksum character varying(64) NOT NULL,
                                         finished_at timestamp with time zone,
                                         migration_name character varying(255) NOT NULL,
                                         logs text,
                                         rolled_back_at timestamp with time zone,
                                         started_at timestamp with time zone DEFAULT now() NOT NULL,
                                         applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO dev;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.categories (
                                 id text NOT NULL,
                                 name text NOT NULL
);


ALTER TABLE public.categories OWNER TO dev;

--
-- Name: feedbacks; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.feedbacks (
                                id text NOT NULL,
                                title text NOT NULL,
                                description text NOT NULL,
                                "categoryId" text,
                                "statusId" text,
                                "authorId" text NOT NULL,
                                "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.feedbacks OWNER TO dev;

--
-- Name: statuses; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.statuses (
                               id text NOT NULL,
                               name text NOT NULL
);


ALTER TABLE public.statuses OWNER TO dev;

--
-- Name: upvotes; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.upvotes (
                              id text NOT NULL,
                              "feedbackId" text NOT NULL,
                              "userId" text NOT NULL,
                              "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.upvotes OWNER TO dev;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.users (
                            id text NOT NULL,
                            email text,
                            password text,
                            avatar text,
                            created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO dev;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: dev
--

INSERT INTO public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count)
VALUES
  ('ea1515e0-4ebd-40e8-bbbb-0ec2c0c228fb', '9e914aba5f7f55d5acf640c515448208a57d247934b387271f8f300f75567605', '2024-12-20 10:59:06.710073+00', '20241220105906_add_feedback_system_entities', NULL, NULL, '2024-12-20 10:59:06.578439+00', 1);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: dev
--

INSERT INTO public.categories (id, name)
VALUES
  ('b7f192c4-9fc0-480c-b12d-ef83f4f547ff', 'c1'),
  ('cead244b-9a8a-4106-b803-1304c4fc4121', 'c2'),
  ('0293a1a6-c540-44ee-8234-4857777679cd', 'c3');


--
-- Data for Name: feedbacks; Type: TABLE DATA; Schema: public; Owner: dev
--

INSERT INTO public.feedbacks (id, title, description, "categoryId", "statusId", "authorId", "createdAt", "updatedAt")
VALUES
  ('426e4073-da55-4c24-a465-8131ea14f0b5', 'feed 8', 'serbserb lal all', 'cead244b-9a8a-4106-b803-1304c4fc4121', '0616fd81-d820-43b3-af24-7b961fea0238', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 14:08:36.3', '2024-12-20 14:08:36.3'),
  ('426e4073-da55-4c24-a405-8131ea12f0b5', 'feed 2', 'erefh', 'cead244b-9a8a-4106-b803-1304c4fc4121', '0616fd81-d820-43b3-af24-7b961fea0238', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 14:08:36.3', '2024-12-20 14:08:36.3'),
  ('466e4073-da55-4c24-a405-8131ea14f0b5', 'feed 4', 'zebzerberb', '0293a1a6-c540-44ee-8234-4857777679cd', '0616fd81-d820-43b3-af24-7b961fea0238', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 14:08:36.3', '2024-12-20 14:08:36.3'),
  ('424e4073-da55-4c24-a405-8131ea14f0b5', 'feed 3', 'lalalala fhbehefb all', 'b7f192c4-9fc0-480c-b12d-ef83f4f547ff', '5e989774-4738-4c9f-9e92-43412a268235', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 14:08:36.3', '2024-12-20 14:08:36.3'),
  ('426e4073-da55-4c24-a405-8131ea16f0b5', 'feed 7', 'rberbesrbserb', 'b7f192c4-9fc0-480c-b12d-ef83f4f547ff', '5e989774-4738-4c9f-9e92-43412a268235', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 14:08:36.3', '2024-12-20 14:08:36.3'),
  ('426e4073-da55-4c24-a405-8131ea14f0b5', 'feed 1', 'lalalala lal all', 'b7f192c4-9fc0-480c-b12d-ef83f4f547ff', '5e989774-4738-4c9f-9e92-43412a268235', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 14:08:36.3', '2024-12-20 14:08:36.3'),
  ('426e4073-da55-4c23-a405-8131ea14f0b5', 'feed 5', 'erberbe', '0293a1a6-c540-44ee-8234-4857777679cd', '84d12876-6caa-4e7f-a531-db04ff88156b', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 14:08:36.3', '2024-12-20 14:08:36.3'),
  ('426e4073-da55-6c24-a405-8131ea14f0b5', 'feed 6', 'brsebsrbe', 'cead244b-9a8a-4106-b803-1304c4fc4121', '84d12876-6caa-4e7f-a531-db04ff88156b', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 14:08:36.3', '2024-12-20 14:08:36.3');


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: dev
--

INSERT INTO public.statuses (id, name)
VALUES
  ('0616fd81-d820-43b3-af24-7b961fea0238', 's1'),
  ('5e989774-4738-4c9f-9e92-43412a268235', 's2'),
  ('84d12876-6caa-4e7f-a531-db04ff88156b', 's3');


--
-- Data for Name: upvotes; Type: TABLE DATA; Schema: public; Owner: dev
--

INSERT INTO public.upvotes (id, "feedbackId", "userId", "createdAt")
VALUES
  ('c1dca708-1153-459f-8f76-4d3fa715808a', '426e4073-da55-4c24-a465-8131ea14f0b5', '30e2c1af-6fe5-4614-9734-70973e4adbb4', '2024-12-20 19:16:44.682');


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dev
--

INSERT INTO public.users (id, email, password, avatar, created_at)
VALUES
  ('30e2c1af-6fe5-4614-9734-70973e4adbb4', 'regerherh@gweg.com', '$2b$10$Dr93CHpuWyq2GU70V9/Ut.mLPcZVwdqKWzWs/u6nE/ZQA.fI7TZ..', NULL, '2024-12-20 14:05:25.32');

--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public._prisma_migrations
  ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.categories
  ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: feedbacks feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.feedbacks
  ADD CONSTRAINT feedbacks_pkey PRIMARY KEY (id);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.statuses
  ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: upvotes upvotes_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.upvotes
  ADD CONSTRAINT upvotes_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.users
  ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: feedbacks feedbacks_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.feedbacks
  ADD CONSTRAINT "feedbacks_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: feedbacks feedbacks_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.feedbacks
  ADD CONSTRAINT "feedbacks_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: feedbacks feedbacks_statusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.feedbacks
  ADD CONSTRAINT "feedbacks_statusId_fkey" FOREIGN KEY ("statusId") REFERENCES public.statuses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: upvotes upvotes_feedbackId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.upvotes
  ADD CONSTRAINT "upvotes_feedbackId_fkey" FOREIGN KEY ("feedbackId") REFERENCES public.feedbacks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: upvotes upvotes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.upvotes
  ADD CONSTRAINT "upvotes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dev
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--
